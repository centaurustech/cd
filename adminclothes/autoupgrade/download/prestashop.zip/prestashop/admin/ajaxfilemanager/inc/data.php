<pre>Array
(
    [currentFolderPath] => ../uploaded/
    [new_folder] => Test
)
</pre>

22/Sep/2008 13:17:12